//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by RAMES.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_POPUP_EDIT                  119
#define IDS_STATUS_PANE1                122
#define IDS_STATUS_PANE2                123
#define IDS_TOOLBAR_STANDARD            124
#define IDS_TOOLBAR_CUSTOMIZE           125
#define ID_VIEW_CUSTOMIZE               126
#define IDR_MAINFRAME                   128
#define IDR_MAINFRAME_256               129
#define IDR_RAMESTYPE                   130
#define IDR_THEME_MENU                  200
#define ID_SET_STYLE                    201
#define ID_VIEW_APPLOOK_WIN_2000        205
#define ID_VIEW_APPLOOK_OFF_XP          206
#define ID_VIEW_APPLOOK_WIN_XP          207
#define ID_VIEW_APPLOOK_OFF_2003        208
#define ID_VIEW_APPLOOK_VS_2005         209
#define ID_VIEW_APPLOOK_VS_2008         210
#define ID_VIEW_APPLOOK_OFF_2007_BLUE   215
#define ID_VIEW_APPLOOK_OFF_2007_BLACK  216
#define ID_VIEW_APPLOOK_OFF_2007_SILVER 217
#define ID_VIEW_APPLOOK_OFF_2007_AQUA   218
#define ID_VIEW_APPLOOK_WINDOWS_7       219
#define IDS_EDIT_MENU                   306
#define IDD_DIALOG_OBLICZENIA_USTAWIENIA 310
#define IDC_COMBO_WARUNKI_I             313
#define IDC_COMBO_METODA_ROZWIAZANIA_UR 314
#define IDD_DIALOG_WYNIKI_USTAWIENIA    315
#define IDC_RADIO_APROKSYMACJA          317
#define IDC_EDIT_GESTOSC_APROKSYMACJI   318
#define IDC_BUTTON_GENERUJ              322
#define IDC_CHECK_ZAGESC_XKROTNIE       323
#define IDC_RADIO_LICZBA_WEZLOW         324
#define IDC_RADIO_ROZKLAD               325
#define IDC_RADIO_ZAKRES                326
#define IDC_EDIT_LICZBA_PUNKTOW         329
#define IDC_EDIT_STALY_KROK             330
#define IDC_EDIT_ZAKRES_OD              331
#define IDC_EDIT_ZAKRES_DO              332
#define IDC_ZAGESC_WSTEPNIE             1004
#define IDC_EDIT_LICZBA_WEZLOW          1005
#define IDC_EDIT_LICZBA_ELEMENTOW       1006
#define IDC_EDIT_KROTNOSC_ZAGESZCZENIA  1007
#define IDC_STATIC_ZAGESC               1008
#define IDC_STATIC_KROTNIE              1009
#define IDC_STATIC_ROZKLAD_TEMP         1018
#define IDC_RADIO2                      1025
#define IDC_RADIO1                      1026
#define IDC_RADIO4                      1030
#define ID_SIATKA_USTAWIENIA            32771
#define ID_OBLICZENIA_USTAWIENIA        32772
#define ID_OBLICZENIA_WYKONAJ           32773
#define ID_WYNIKI_ZAPISZ                32775
#define ID_STRUKTURA_WCZYTAJ            32776
#define ID_WYNIKI_WYSWIETL              32782
#define ID_DANE_WCZYTAJ                 32784
#define ID_WYNIKI_ZAPISZJAKO            32785
#define ID_WYNIKI_USTAWIENIA            32791

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        316
#define _APS_NEXT_COMMAND_VALUE         32792
#define _APS_NEXT_CONTROL_VALUE         1033
#define _APS_NEXT_SYMED_VALUE           333
#endif
#endif
