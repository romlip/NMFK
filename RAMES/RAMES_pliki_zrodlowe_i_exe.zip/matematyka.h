#pragma once

namespace matematyka
{
	double rozniczka();
	double calka(double a, double b, double* f, double *x, int n);
}