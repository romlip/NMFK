#include "pch.h"
#include "matematyka.h"

double matematyka::rozniczka()
{
    return 0.0;
}

double matematyka::calka(double a, double b, double* f, double* x, int n)
{
    // wyklad 09, slajdy 35-36

    double H2[2] = { 1,1 };
    double ksi2[2] = { -0.577350269189626, 0.577350269189626 };

    }
    double suma = 0;
    for (int i = 0; i < n; i++)
        suma+= 
    return suma;
}
