#include "pch.h"
#include "KMacierzSRF.h"
